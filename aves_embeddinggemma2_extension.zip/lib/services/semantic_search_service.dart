// Serwis integracji wyszukiwania semantycznego we Flutterze dla Aves
import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

class SemanticMatch {
  final int entryId;
  final double score; // 0.0 do 1.0 (zgodność semantyczna)

  const SemanticMatch({
    required this.entryId,
    required this.score,
  });

  factory SemanticMatch.fromMap(Map<dynamic, dynamic> map) {
    return SemanticMatch(
      entryId: (map['id'] as num).toInt(),
      score: (map['score'] as num).toDouble(),
    );
  }
}

class SemanticSearchService {
  static const MethodChannel _channel = MethodChannel('deckers.aves/semantic_search');

  static final SemanticSearchService _instance = SemanticSearchService._internal();
  factory SemanticSearchService() => _instance;
  SemanticSearchService._internal();

  bool _isInitialized = false;

  /// Inicjalizuje natywne moduły (MediaPipe Gemma + sqlite-vec)
  Future<bool> initialize() async {
    if (_isInitialized) return true;
    try {
      final bool ready = await _channel.invokeMethod<bool>('isReady') ?? false;
      _isInitialized = ready;
      return ready;
    } on PlatformException catch (e) {
      debugPrint('[SemanticSearch] Błąd inicjalizacji: ${e.message}');
      return false;
    }
  }

  /// Wykonuje semantyczne wyszukiwanie zdjęć na podstawie zapytania tekstowego.
  /// Zwraca listę dopasowań posortowaną malejąco po stopniu podobieństwa.
  Future<List<SemanticMatch>> search(
    String query, {
    int limit = 50,
    double threshold = 0.45,
  }) async {
    if (query.trim().isEmpty) return [];

    try {
      final List<dynamic>? rawResults = await _channel.invokeMethod<List<dynamic>>(
        'search',
        {
          'query': query.trim(),
          'limit': limit,
          'threshold': threshold,
        },
      );

      if (rawResults == null) return [];

      return rawResults
          .whereType<Map<dynamic, dynamic>>()
          .map((item) => SemanticMatch.fromMap(item))
          .toList();
    } on PlatformException catch (e) {
      debugPrint('[SemanticSearch] Błąd wyszukiwania dla "$query": ${e.message}');
      rethrow;
    } catch (e) {
      debugPrint('[SemanticSearch] Nieoczekiwany wyjątek: $e');
      return [];
    }
  }

  /// Wymusza natychmiastowe zindeksowanie konkretnego zdjęcia
  Future<bool> indexSingleImage(int id, String path) async {
    try {
      final bool? success = await _channel.invokeMethod<bool>(
        'indexSingleImage',
        {'id': id, 'path': path},
      );
      return success ?? false;
    } catch (e) {
      debugPrint('[SemanticSearch] Błąd indeksowania pojedynczego wpisu ($id): $e');
      return false;
    }
  }
}