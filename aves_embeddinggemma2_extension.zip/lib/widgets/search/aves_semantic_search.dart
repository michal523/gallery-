// Modyfikacja widoku wyszukiwania w Aves (search_page.dart / aves_search_bar.dart)
import 'package:flutter/material.dart';
import 'package:aves/model/entry.dart';
import 'package:aves/model/source/collection_lens.dart';
import 'package:aves/services/semantic_search_service.dart';

class AvesSemanticSearchBar extends StatefulWidget {
  final CollectionLens collection;
  final ValueChanged<Set<AvesEntry>> onResultsFiltered;

  const AvesSemanticSearchBar({
    super.key,
    required this.collection,
    required this.onResultsFiltered,
  });

  @override
  State<AvesSemanticSearchBar> createState() => _AvesSemanticSearchBarState();
}

class _AvesSemanticSearchBarState extends State<AvesSemanticSearchBar> {
  final TextEditingController _controller = TextEditingController();
  final SemanticSearchService _semanticService = SemanticSearchService();

  bool _isSemanticMode = true;
  bool _isSearching = false;
  String? _errorMessage;
  double _threshold = 0.50; // Próg podobieństwa cosinusowego

  @override
  void initState() {
    super.initState();
    _semanticService.initialize();
  }

  Future<void> _performSearch(String query) async {
    if (query.trim().isEmpty) {
      widget.onResultsFiltered(widget.collection.source.visibleEntries.toSet());
      return;
    }

    setState(() {
      _isSearching = true;
      _errorMessage = null;
    });

    try {
      // Wywołanie wyszukiwania przez natywny MethodChannel
      final matches = await _semanticService.search(
        query,
        limit: 100,
        threshold: _threshold,
      );

      final matchIds = matches.map((m) => m.entryId).toSet();

      // Filtrujemy kolekcję Aves wg pasujących identyfikatorów z sqlite-vec
      final filteredEntries = widget.collection.source.visibleEntries
          .where((entry) => matchIds.contains(entry.id))
          .toSet();

      widget.onResultsFiltered(filteredEntries);
    } catch (e) {
      setState(() {
        _errorMessage = 'Błąd wyszukiwania semantycznego: $e';
      });
    } finally {
      if (mounted) {
        setState(() {
          _isSearching = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _controller,
                  textInputAction: TextInputAction.search,
                  onSubmitted: _performSearch,
                  decoration: InputDecoration(
                    hintText: _isSemanticMode
                        ? 'Wyszukaj np. "pies na plaży", "paragon", "czerwone auto"...'
                        : 'Szukaj standardowo wg tagów lub albumu...',
                    prefixIcon: Icon(
                      _isSemanticMode ? Icons.auto_awesome : Icons.search,
                      color: _isSemanticMode ? theme.colorScheme.primary : null,
                    ),
                    suffixIcon: _isSearching
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: Padding(
                              padding: EdgeInsets.all(12),
                              child: CircularProgressIndicator(strokeWidth: 2),
                            ),
                          )
                        : IconButton(
                            icon: const Icon(Icons.clear),
                            onPressed: () {
                              _controller.clear();
                              _performSearch('');
                            },
                          ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(24),
                    ),
                    filled: true,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              // Przełącznik trybu semantycznego Gemma AI
              FilterChip(
                label: const Text('Gemma AI'),
                selected: _isSemanticMode,
                avatar: const Icon(Icons.psychology, size: 18),
                onSelected: (selected) {
                  setState(() {
                    _isSemanticMode = selected;
                  });
                },
              ),
            ],
          ),
          if (_errorMessage != null)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text(
                _errorMessage!,
                style: TextStyle(color: theme.colorScheme.error, fontSize: 12),
              ),
            ),
        ],
      ),
    );
  }
}