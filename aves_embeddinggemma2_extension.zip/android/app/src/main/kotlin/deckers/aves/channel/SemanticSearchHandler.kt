package deckers.aves.channel

import android.content.Context
import android.util.Log
import deckers.aves.model.AvesDatabase
import deckers.aves.semantic.EmbeddingGemmaHelper
import deckers.aves.semantic.SqliteVecHelper
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Obsługuje komunikację Flutter <-> Kotlin przez MethodChannel "deckers.aves/semantic_search".
 * Integruje zapytania z modelem embeddinggemma2 i bazą sqlite-vec.
 */
class SemanticSearchHandler(
    private val context: Context,
    messenger: BinaryMessenger
) : MethodChannel.MethodCallHandler {

    companion object {
        const val CHANNEL_NAME = "deckers.aves/semantic_search"
        private const val TAG = "SemanticSearchHandler"
    }

    private val channel = MethodChannel(messenger, CHANNEL_NAME)
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val gemmaHelper by lazy { EmbeddingGemmaHelper(context) }
    private val vecHelper by lazy {
        val db = AvesDatabase.getInstance(context).writableDatabase
        SqliteVecHelper(context, db)
    }

    init {
        channel.setMethodCallHandler(this)
    }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "isReady" -> {
                scope.launch {
                    val initialized = withContext(Dispatchers.IO) {
                        gemmaHelper.initialize() && vecHelper.loadExtension()
                    }
                    result.success(initialized)
                }
            }

            "search" -> {
                val query = call.argument<String>("query")
                val limit = call.argument<Int>("limit") ?: 50
                val threshold = call.argument<Double>("threshold")?.toFloat() ?: 0.50f

                if (query.isNullOrBlank()) {
                    result.error("INVALID_QUERY", "Tekst zapytania nie może być pusty", null)
                    return
                }

                scope.launch {
                    try {
                        val matches = withContext(Dispatchers.Default) {
                            // 1. Generowanie wektora zapytania modelem embeddinggemma2
                            val queryVector = gemmaHelper.embedText(query)
                                ?: throw IllegalStateException("Nie udało się wygenerować wektora dla tekstu")

                            // 2. Wyszukanie w sqlite-vec najbliższych sąsiadów wg metryki cosinusowej
                            val knnResults = vecHelper.searchKNN(queryVector, limit, 1.0f - threshold)

                            // 3. Mapowanie wyników do formatu przyjaznego dla Fluttera
                            knnResults.map { (id, score) ->
                                mapOf(
                                    "id" to id,
                                    "score" to score.toDouble()
                                )
                            }
                        }

                        result.success(matches)
                    } catch (e: Exception) {
                        Log.e(TAG, "Błąd podczas wyszukiwania semantycznego: ${e.message}", e)
                        result.error("SEARCH_ERROR", e.message ?: "Błąd zapytania wektorowego", null)
                    }
                }
            }

            "indexSingleImage" -> {
                val entryId = call.argument<Number>("id")?.toLong()
                val path = call.argument<String>("path")

                if (entryId == null || path.isNullOrEmpty()) {
                    result.error("INVALID_ARGS", "Wymagane ID i ścieżka do zdjęcia", null)
                    return
                }

                scope.launch {
                    val ok = withContext(Dispatchers.IO) {
                        val vector = gemmaHelper.embedImage(path)
                        if (vector != null) {
                            vecHelper.upsertVector(entryId, vector)
                        } else false
                    }
                    result.success(ok)
                }
            }

            else -> result.notImplemented()
        }
    }

    fun dispose() {
        channel.setMethodCallHandler(null)
        gemmaHelper.close()
    }
}