package deckers.aves.semantic

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.Constraints
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import deckers.aves.model.AvesDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Worker analizujący nowe zdjęcia w tle za pomocą embeddinggemma2.
 * Podpina się pod istniejący cykl skanowania multimediów w Aves (MediaFetchService).
 */
class AvesSemanticScannerWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    companion object {
        const val TAG = "AvesSemanticScanner"
        const val KEY_ENTRY_IDS = "entry_ids"
        const val KEY_ENTRY_PATHS = "entry_paths"

        /**
         * Uruchamia zaplanowane zadanie analizy w tle z ograniczeniami systemowymi (np. ładowanie / idle).
         */
        fun enqueue(context: Context, entryIds: LongArray, entryPaths: Array<String>) {
            val constraints = Constraints.Builder()
                .setRequiresBatteryNotLow(true)
                .build()

            val workRequest = OneTimeWorkRequestBuilder<AvesSemanticScannerWorker>()
                .setConstraints(constraints)
                .setInputData(workDataOf(
                    KEY_ENTRY_IDS to entryIds,
                    KEY_ENTRY_PATHS to entryPaths
                ))
                .addTag(TAG)
                .build()

            WorkManager.getInstance(context).enqueue(workRequest)
            Log.d(TAG, "Zlecono indeksowanie semantyczne dla ${entryIds.size} nowych zdjęć.")
        }
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val entryIds = inputData.getLongArray(KEY_ENTRY_IDS) ?: return@withContext Result.success()
        val entryPaths = inputData.getStringArray(KEY_ENTRY_PATHS) ?: return@withContext Result.success()

        if (entryIds.isEmpty()) return@withContext Result.success()

        Log.i(TAG, "Rozpoczynam analizę ${entryIds.size} zdjęć w tle przez embeddinggemma2...")

        val gemmaHelper = EmbeddingGemmaHelper(applicationContext)
        if (!gemmaHelper.initialize()) {
            Log.e(TAG, "Nie można zainicjalizować modelu embeddinggemma2 w tle.")
            return@withContext Result.retry()
        }

        // Dostęp do istniejącej instancji SQLite w Aves
        val db = AvesDatabase.getInstance(applicationContext).writableDatabase
        val sqliteVecHelper = SqliteVecHelper(applicationContext, db)
        sqliteVecHelper.loadExtension()

        var successCount = 0

        try {
            for (i in entryIds.indices) {
                if (isStopped) {
                    Log.w(TAG, "Przerwano zadanie WorkManager (np. niskie zasilanie)")
                    break
                }

                val id = entryIds[i]
                val path = entryPaths[i]

                val vector = gemmaHelper.embedImage(path)
                if (vector != null) {
                    val saved = sqliteVecHelper.upsertVector(id, vector)
                    if (saved) successCount++
                }

                // Drobna pauza redukująca nagrzewanie procesora przy tysiącach zdjęć
                if (i % 10 == 0) {
                    kotlinx.coroutines.delay(50)
                }
            }
        } finally {
            gemmaHelper.close()
        }

        Log.i(TAG, "Zakończono analizę semantyczną w tle. Pomyślnie zindeksowano: $successCount/${entryIds.size} zdjęć.")
        Result.success()
    }
}