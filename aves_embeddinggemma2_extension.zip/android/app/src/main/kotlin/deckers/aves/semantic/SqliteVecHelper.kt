package deckers.aves.semantic

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.util.Log
import io.github.asg017.sqlitevec.SqliteVec
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Zarządza integracją sqlite-vec w bazie SQLite aplikacji Aves.
 * Dodaje wirtualną tabelę 'vec_entries' przechowującą identyfikatory zdjęć oraz ich wektory.
 */
class SqliteVecHelper(private val context: Context, private val db: SQLiteDatabase) {

    companion object {
        private const val TAG = "SqliteVecHelper"
        const val VEC_TABLE_NAME = "vec_entries"
        const val VECTOR_DIM = 768
    }

    private var isExtensionLoaded = false

    /**
     * Ładuje rozszerzenie sqlite-vec do istniejącej instancji bazy danych Aves.
     */
    @Synchronized
    fun loadExtension(): Boolean {
        if (isExtensionLoaded) return true

        return try {
            // Inicjalizacja natywnego modułu sqlite-vec
            SqliteVec.load(db)
            isExtensionLoaded = true
            Log.i(TAG, "Rozszerzenie sqlite-vec załadowane pomyślnie do bazy Aves.")
            createVirtualTable()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Nie udało się załadować rozszerzenia sqlite-vec: ${e.message}", e)
            false
        }
    }

    /**
     * Tworzy wirtualną tabelę sqlite-vec do indeksowania wektorów o metryce cosinusowej.
     */
    private fun createVirtualTable() {
        try {
            // Tabela pomocnicza ze statusem indeksowania
            db.execSQL("""
                CREATE TABLE IF NOT EXISTS semantic_metadata (
                    entry_id INTEGER PRIMARY KEY,
                    indexed_at INTEGER NOT NULL,
                    model_version TEXT NOT NULL
                );
            """.trimIndent())

            // Wirtualna tabela sqlite-vec (vec0) z metryką cosinusową
            val createVecTable = """
                CREATE VIRTUAL TABLE IF NOT EXISTS $VEC_TABLE_NAME USING vec0(
                    entry_id INTEGER PRIMARY KEY,
                    embedding float[$VECTOR_DIM] distance_metric=cosine
                );
            """.trimIndent()
            db.execSQL(createVecTable)
            Log.i(TAG, "Wirtualna tabela $VEC_TABLE_NAME gotowa.")
        } catch (e: SQLiteException) {
            Log.e(TAG, "Błąd podczas tworzenia tabeli vec_entries: ${e.message}", e)
        }
    }

    /**
     * Zapisuje lub aktualizuje wektor dla danego identyfikatora zdjęcia (entry_id).
     */
    fun upsertVector(entryId: Long, vector: FloatArray): Boolean {
        if (!isExtensionLoaded && !loadExtension()) return false
        if (vector.size != VECTOR_DIM) {
            Log.e(TAG, "Nieprawidłowy wymiar wektora: ${vector.size}, oczekiwano $VECTOR_DIM")
            return false
        }

        return try {
            db.beginTransaction()
            try {
                // Usuń poprzedni wpis, jeśli istnieje (vec0 nie wspiera bezpośredniego INSERT OR REPLACE)
                db.execSQL("DELETE FROM $VEC_TABLE_NAME WHERE entry_id = ?", arrayOf(entryId))

                // Konwersja wektora FloatArray na binarny format Little-Endian (BLOB)
                val byteBuffer = ByteBuffer.allocate(vector.size * 4).order(ByteOrder.LITTLE_ENDIAN)
                for (v in vector) {
                    byteBuffer.putFloat(v)
                }
                val vectorBlob = byteBuffer.array()

                val insertStmt = db.compileStatement(
                    "INSERT INTO $VEC_TABLE_NAME(entry_id, embedding) VALUES (?, ?)"
                )
                insertStmt.bindLong(1, entryId)
                insertStmt.bindBlob(2, vectorBlob)
                insertStmt.executeInsert()

                // Zapisz znacznik czasu
                db.execSQL(
                    "INSERT OR REPLACE INTO semantic_metadata(entry_id, indexed_at, model_version) VALUES (?, ?, ?)",
                    arrayOf(entryId, System.currentTimeMillis(), "embeddinggemma2-v1")
                )

                db.setTransactionSuccessful()
                true
            } finally {
                db.endTransaction()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Błąd zapisu wektora dla entry_id=$entryId: ${e.message}", e)
            false
        }
    }

    /**
     * Wyszukuje najbliższe wektory w sqlite-vec wg metryki cosinusowej.
     * Zwraca listę par (entry_id, podobieństwo [0.0 - 1.0]).
     */
    fun searchKNN(queryVector: FloatArray, limit: Int = 50, maxDistance: Float = 0.65f): List<Pair<Long, Float>> {
        if (!isExtensionLoaded && !loadExtension()) return emptyList()

        val results = mutableListOf<Pair<Long, Float>>()
        val byteBuffer = ByteBuffer.allocate(queryVector.size * 4).order(ByteOrder.LITTLE_ENDIAN)
        for (v in queryVector) {
            byteBuffer.putFloat(v)
        }
        val queryBlob = byteBuffer.array()

        val sql = """
            SELECT entry_id, distance 
            FROM $VEC_TABLE_NAME 
            WHERE embedding MATCH ? 
            ORDER BY distance 
            LIMIT ?;
        """.trimIndent()

        try {
            db.rawQuery(sql, arrayOf(queryBlob as Any, limit as Any)).use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow("entry_id")
                val distCol = cursor.getColumnIndexOrThrow("distance")

                while (cursor.moveToNext()) {
                    val entryId = cursor.getLong(idCol)
                    val distance = cursor.getFloat(distCol)

                    // Przeliczenie odległości cosinusowej (1 - cos_sim) na współczynnik dopasowania (0..1)
                    if (distance <= maxDistance) {
                        val similarityScore = (1.0f - (distance / 2.0f)).coerceIn(0.0f, 1.0f)
                        results.add(Pair(entryId, similarityScore))
                    }
                }
            }
        } catch (e: SQLiteException) {
            Log.e(TAG, "Błąd zapytania sqlite-vec KNN: ${e.message}", e)
        } catch (e: Exception) {
            Log.e(TAG, "Nieoczekiwany błąd searchKNN: ${e.message}", e)
        }

        return results
    }

    /**
     * Sprawdza, które identyfikatory zdjęć nie zostały jeszcze zindeksowane wektorowo.
     */
    fun getUnindexedEntryIds(allEntryIds: List<Long>): List<Long> {
        val indexedIds = mutableSetOf<Long>()
        try {
            db.rawQuery("SELECT entry_id FROM semantic_metadata", null).use { cursor ->
                val col = cursor.getColumnIndexOrThrow("entry_id")
                while (cursor.moveToNext()) {
                    indexedIds.add(cursor.getLong(col))
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Błąd odczytu zindeksowanych ID: ${e.message}")
        }
        return allEntryIds.filter { !indexedIds.contains(it) }
    }
}