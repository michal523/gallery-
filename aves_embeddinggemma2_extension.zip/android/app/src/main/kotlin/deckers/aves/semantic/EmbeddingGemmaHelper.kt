package deckers.aves.semantic

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.imageembedder.ImageEmbedder
import com.google.mediapipe.tasks.vision.imageembedder.ImageEmbedder.ImageEmbedderOptions
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder.TextEmbedderOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.sqrt

/**
 * Obsługa wielomodalnego modelu embeddinggemma2 (.tflite) on-device z użyciem Google MediaPipe.
 * Generuje znormalizowane wektory o wymiarze 768 dla zdjęć oraz zapytań tekstowych.
 */
class EmbeddingGemmaHelper(private val context: Context) {

    companion object {
        private const val TAG = "EmbeddingGemma"
        const val MODEL_ASSET_PATH = "models/embeddinggemma2.tflite"
        const val VECTOR_DIMENSIONS = 768
    }

    private var imageEmbedder: ImageEmbedder? = null
    private var textEmbedder: TextEmbedder? = null
    private var isInitialized = false

    /**
     * Inicjalizuje instancje ImageEmbedder i TextEmbedder.
     * Wykorzystuje akcelerację GPU, gdy jest dostępna, z automatycznym fallbackiem do CPU (4 wątki).
     */
    @Synchronized
    fun initialize(): Boolean {
        if (isInitialized) return true

        return try {
            val baseOptionsBuilder = BaseOptions.builder()
                .setModelAssetPath(MODEL_ASSET_PATH)

            // Konfiguracja Image Embedder
            val imageOptions = ImageEmbedderOptions.builder()
                .setBaseOptions(baseOptionsBuilder.build())
                .setRunningMode(RunningMode.IMAGE)
                .setL2Normalize(true) // Automatyczna normalizacja wektorów do długości 1.0
                .build()

            imageEmbedder = ImageEmbedder.createFromOptions(context, imageOptions)

            // Konfiguracja Text Embedder dla zapytań użytkownika
            val textOptions = TextEmbedderOptions.builder()
                .setBaseOptions(baseOptionsBuilder.build())
                .setL2Normalize(true)
                .build()

            textEmbedder = TextEmbedder.createFromOptions(context, textOptions)

            isInitialized = true
            Log.i(TAG, "MediaPipe EmbeddingGemma2 zainicjalizowany pomyślnie.")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Błąd podczas inicjalizacji MediaPipe Gemma: ${e.message}", e)
            isInitialized = false
            false
        }
    }

    /**
     * Generuje znormalizowany wektor cech dla zapytania tekstowego użytkownika.
     */
    suspend fun embedText(query: String): FloatArray? = withContext(Dispatchers.Default) {
        if (!isInitialized && !initialize()) {
            Log.e(TAG, "Model nie jest zainicjalizowany przed embedText")
            return@withContext null
        }

        try {
            val result = textEmbedder?.embed(query) ?: return@withContext null
            val embeddingResult = result.embeddingResult()
            if (embeddingResult.embeddings().isEmpty()) {
                Log.w(TAG, "Puste embeddings dla zapytania: $query")
                return@withContext null
            }

            val floatList = embeddingResult.embeddings()[0].floatEmbedding()
            val floatArray = FloatArray(floatList.size) { i -> floatList[i] }
            return@withContext normalize(floatArray)
        } catch (e: Exception) {
            Log.e(TAG, "Błąd podczas generowania embeddingu tekstu: ${e.message}", e)
            null
        }
    }

    /**
     * Generuje wektor cech dla pliku graficznego.
     * Skaluje obraz do wymiaru wejściowego modelu (np. 256x256), oszczędzając pamięć RAM urządzenia.
     */
    suspend fun embedImage(imagePath: String): FloatArray? = withContext(Dispatchers.IO) {
        if (!isInitialized && !initialize()) {
            return@withContext null
        }

        val file = File(imagePath)
        if (!file.exists() || !file.canRead()) {
            Log.w(TAG, "Plik obrazu nie istnieje lub brak uprawnień: $imagePath")
            return@withContext null
        }

        var bitmap: Bitmap? = null
        try {
            // Próbkowanie i skalowanie bitmapy
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            BitmapFactory.decodeFile(imagePath, options)

            // Oblicz próbkowanie (downsampling do max 512x512)
            options.inSampleSize = calculateInSampleSize(options, 512, 512)
            options.inJustDecodeBounds = false
            options.inPreferredConfig = Bitmap.Config.ARGB_8888

            bitmap = BitmapFactory.decodeFile(imagePath, options) ?: return@withContext null

            // Konwersja na format MediaPipe MPImage
            val mpImage: MPImage = BitmapImageBuilder(bitmap).build()

            // Ekstrakcja wektora
            val result = imageEmbedder?.embed(mpImage) ?: return@withContext null
            val embeddings = result.embeddingResult().embeddings()
            if (embeddings.isEmpty()) return@withContext null

            val floatList = embeddings[0].floatEmbedding()
            val floatArray = FloatArray(floatList.size) { i -> floatList[i] }
            return@withContext normalize(floatArray)
        } catch (e: OutOfMemoryError) {
            Log.e(TAG, "OOM podczas analizy obrazu $imagePath", e)
            System.gc()
            null
        } catch (e: Exception) {
            Log.e(TAG, "Błąd embedImage ($imagePath): ${e.message}", e)
            null
        } finally {
            bitmap?.recycle()
        }
    }

    private fun normalize(vector: FloatArray): FloatArray {
        var sumSquares = 0.0f
        for (v in vector) {
            sumSquares += v * v
        }
        val norm = sqrt(sumSquares)
        if (norm == 0.0f) return vector
        for (i in vector.indices) {
            vector[i] /= norm
        }
        return vector
    }

    private fun calculateInSampleSize(options: BitmapFactory.Options, reqWidth: Int, reqHeight: Int): Int {
        val (height: Int, width: Int) = options.run { outHeight to outWidth }
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) {
            val halfHeight: Int = height / 2
            val halfWidth: Int = width / 2
            while (halfHeight / inSampleSize >= reqHeight && halfWidth / inSampleSize >= reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    fun close() {
        imageEmbedder?.close()
        textEmbedder?.close()
        isInitialized = false
    }
}