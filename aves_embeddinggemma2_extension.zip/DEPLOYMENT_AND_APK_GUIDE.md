# Kompletna Instrukcja Wdrożenia i Kompilacji APK (Aves + embeddinggemma2 + sqlite-vec)

Niniejszy przewodnik opisuje procedurę krok po kroku wdrożenia zmian w istniejącym repozytorium **Aves** oraz przygotowania gotowej paczki APK.

---

### Krok 1: Przygotowanie modelu embeddinggemma2 (.tflite)
1. Pobierz lub skonwertuj model **embeddinggemma2** do formatu MediaPipe / TensorFlow Lite (.tflite).
2. Umieść plik modelu w folderze aplikacji Androida:
   ```bash
   mkdir -p android/app/src/main/assets/models/
   cp embeddinggemma2.tflite android/app/src/main/assets/models/
   ```
   *Wskazówka: Plik nie powinien być kompresowany w pliku APK (co zapewnia wpis `noCompress "tflite"` w `android/app/build.gradle`).*

---

### Krok 2: Umieszczenie biblioteki natywnej sqlite-vec
1. Biblioteka `sqlite-vec` wymaga natywnych bibliotek współdzielonych (`.so`) dla architektury Androida (`arm64-v8a`, `armeabi-v7a`, `x86_64`).
2. Możesz skorzystać z gotowego pakietu Maven `io.github.asg017:sqlite-vec-android:0.1.1` zadeklarowanego w `build.gradle` lub umieścić pliki `.so` w:
   ```bash
   android/app/src/main/jniLibs/arm64-v8a/libsqlitevec.so
   android/app/src/main/jniLibs/armeabi-v7a/libsqlitevec.so
   android/app/src/main/jniLibs/x86_64/libsqlitevec.so
   ```

---

### Krok 3: Dodanie plików źródłowych Kotlina i Fluttera
Skopiuj załączone pliki do odpowiednich ścieżek w strukturze Aves:
1. `EmbeddingGemmaHelper.kt` -> `android/app/src/main/kotlin/deckers/aves/semantic/`
2. `SqliteVecHelper.kt` -> `android/app/src/main/kotlin/deckers/aves/semantic/`
3. `AvesSemanticScannerWorker.kt` -> `android/app/src/main/kotlin/deckers/aves/semantic/`
4. `SemanticSearchHandler.kt` -> `android/app/src/main/kotlin/deckers/aves/channel/`
5. `semantic_search_service.dart` -> `lib/services/`
6. `aves_semantic_search.dart` -> `lib/widgets/search/`

---

### Krok 4: Wpięcie handlera w MainActivity.kt
W pliku `android/app/src/main/kotlin/deckers/aves/MainActivity.kt` w metodzie `configureFlutterEngine`:
```kotlin
override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
    super.configureFlutterEngine(flutterEngine)
    // Rejestracja kanału wyszukiwania semantycznego
    SemanticSearchHandler(applicationContext, flutterEngine.dartExecutor.binaryMessenger)
}
```

---

### Krok 5: Kompilacja APK (flutter build apk)
Na stacji deweloperskiej z zainstalowanym Flutter SDK i Android SDK:
```bash
# 1. Pobranie pakietów Fluttera
flutter pub get

# 2. Czyszczenie poprzednich artefaktów (zalecane przy zmianach NDK / C++)
flutter clean
flutter pub get

# 3. Kompilacja wersji debugującej APK
flutter build apk --debug

# 4. Lokalizacja gotowego pliku APK:
# build/app/outputs/flutter-apk/app-debug.apk
```

---

### Obsługa Błędów w Bazie Danych (sqlite-vec & SQLite)
- **SQLITE_CANTOPEN / UnsatisfiedLinkError**: Gdy brak biblioteki `libsqlitevec.so` dla danej architektury CPU urządzenia. Zabezpieczono automatycznym fallbackiem do klasycznego wyszukiwania tekstowego w Aves.
- **SQLITE_BUSY / SQLITE_LOCKED**: Wynikające z jednoczesnego skanowania biblioteki mediów w tle i zapytania użytkownika. Obsługiwane przez transakcje `BEGIN IMMEDIATE` oraz ponowienia w `AvesSemanticScannerWorker`.
- **OutOfMemoryError (OOM)**: Zapobieganie przez próbkowanie bitmapy do maksymalnie 512x512 pikseli i natychmiastowe zwalnianie pamięci (`bitmap.recycle()`).