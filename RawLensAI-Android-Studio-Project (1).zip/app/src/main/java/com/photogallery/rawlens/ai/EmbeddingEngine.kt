package com.photogallery.rawlens.ai

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.imageembedder.ImageEmbedder
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import kotlin.math.sqrt

class EmbeddingEngine(context: Context) {
    private var imageEmbedder: ImageEmbedder? = null
    private var textEmbedder: TextEmbedder? = null

    init {
        // Model wielomodalny kompatybilny z EmbeddingGemma / MobileCLIP w formacie .tflite w katalogu assets
        val baseOptions = BaseOptions.builder()
            .setModelAssetPath("embedding_gemma.tflite")
            .setDelegate(Delegate.NNAPI) // Edge 50 Pro NPU akceleracja Snapdragon 7 Gen 3
            .build()

        try {
            val imageOptions = ImageEmbedder.ImageEmbedderOptions.builder()
                .setBaseOptions(baseOptions)
                .setQuantize(false)
                .build()
            imageEmbedder = ImageEmbedder.createFromOptions(context, imageOptions)

            val textOptions = TextEmbedder.TextEmbedderOptions.builder()
                .setBaseOptions(baseOptions)
                .setQuantize(false)
                .build()
            textEmbedder = TextEmbedder.createFromOptions(context, textOptions)
        } catch (_: Exception) {}
    }

    fun embedImage(bitmap: Bitmap): FloatArray {
        return try {
            val mpImage = BitmapImageBuilder(bitmap).build()
            val result = imageEmbedder?.embed(mpImage)
            result?.embeddingResult()?.embeddings()?.firstOrNull()?.floatEmbedding() 
                ?: FloatArray(768) { 0f }
        } catch (e: Exception) {
            FloatArray(768) { 0f }
        }
    }

    fun embedText(text: String): FloatArray {
        return try {
            val result = textEmbedder?.embed(text)
            result?.embeddingResult()?.embeddings()?.firstOrNull()?.floatEmbedding() 
                ?: FloatArray(768) { 0f }
        } catch (e: Exception) {
            FloatArray(768) { 0f }
        }
    }

    companion object {
        // Podobieństwo cosinusowe: dot(A, B) / (|A| * |B|)
        fun cosineSimilarity(vecA: FloatArray, vecB: FloatArray): Float {
            var dot = 0f
            var normA = 0f
            var normB = 0f
            val size = minOf(vecA.size, vecB.size)
            for (i in 0 until size) {
                dot += vecA[i] * vecB[i]
                normA += vecA[i] * vecA[i]
                normB += vecB[i] * vecB[i]
            }
            val denom = sqrt(normA) * sqrt(normB)
            return if (denom > 0f) dot / denom else 0f
        }
    }
}