package com.photogallery.rawlens

import android.app.Application
import com.photogallery.rawlens.worker.WorkScheduler

class GalleryApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Harmonogramowanie indeksowania w stanie bezczynności i ładowania
        WorkScheduler.scheduleBackgroundIndexing(this)
    }
}