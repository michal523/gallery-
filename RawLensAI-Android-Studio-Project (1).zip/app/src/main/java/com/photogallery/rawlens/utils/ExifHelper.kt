package com.photogallery.rawlens.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.text.DecimalFormat

data class PhotographerExif(
    val camera: String = "Nieznany",
    val lens: String = "Nieznany",
    val focalLength: String = "-- mm",
    val shutterSpeed: String = "-- s",
    val aperture: String = "f/--",
    val iso: String = "ISO --",
    val resolution: String = "-- x --",
    val fileSize: String = "-- MB",
    val author: String = "Nikodem Jaracz",
    val copyright: String = "© 2026 Nikodem Jaracz",
    val title: String = ""
)

object ExifHelper {
    fun parseExif(context: Context, uri: Uri): PhotographerExif {
        return try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val exif = ExifInterface(stream)
                val make = exif.getAttribute(ExifInterface.TAG_MAKE) ?: ""
                val model = exif.getAttribute(ExifInterface.TAG_MODEL) ?: "Nieznany aparat"
                val camera = if (model.startsWith(make, ignoreCase = true)) model else "$make $model".trim()
                val lens = exif.getAttribute(ExifInterface.TAG_LENS_MODEL) ?: "Obiektyw standardowy"
                
                val focal = exif.getAttributeDouble(ExifInterface.TAG_FOCAL_LENGTH, 0.0)
                val focalStr = if (focal > 0) "${focal.toInt()} mm" else "-- mm"

                val expTime = exif.getAttributeDouble(ExifInterface.TAG_EXPOSURE_TIME, 0.0)
                val shutterStr = when {
                    expTime <= 0.0 -> "-- s"
                    expTime < 1.0 -> "1/${(1.0 / expTime).toInt()} s"
                    else -> "${DecimalFormat("#.#").format(expTime)} s"
                }

                val fNumber = exif.getAttributeDouble(ExifInterface.TAG_F_NUMBER, 0.0)
                val apertureStr = if (fNumber > 0) "f/${DecimalFormat("#.#").format(fNumber)}" else "f/--"

                val iso = exif.getAttribute(ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY) ?: "--"

                val width = exif.getAttributeInt(ExifInterface.TAG_IMAGE_WIDTH, 0)
                val length = exif.getAttributeInt(ExifInterface.TAG_IMAGE_LENGTH, 0)
                val resStr = if (width > 0 && length > 0) "$width × $length" else "-- × --"

                var sizeStr = "-- MB"
                context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                    val bytes = pfd.statSize
                    sizeStr = "${DecimalFormat("#.##").format(bytes.toDouble() / (1024 * 1024))} MB"
                }

                PhotographerExif(camera, lens, focalStr, shutterStr, apertureStr, "ISO $iso", resStr, sizeStr)
            } ?: PhotographerExif()
        } catch (e: Exception) {
            PhotographerExif()
        }
    }

    // Wyciąganie zaszytego JPEG/miniatury z plików .RW2, .CR3, .NEF oraz .JPG
    fun extractEmbeddedThumbnail(context: Context, uri: Uri): Bitmap? {
        return try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val exif = ExifInterface(stream)
                if (exif.hasThumbnail()) {
                    val thumbData = exif.thumbnailBytes
                    if (thumbData != null) {
                        return downsampleBitmap(thumbData, 224, 224)
                    }
                }
                // Fallback: próbkowanie z pełnego strumienia (optymalizacja RAM dla Edge 50 Pro)
                context.contentResolver.openInputStream(uri)?.use { directStream ->
                    val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeStream(directStream, null, options)
                    val sampleSize = calculateInSampleSize(options, 224, 224)

                    context.contentResolver.openInputStream(uri)?.use { decodeStream ->
                        val finalOptions = BitmapFactory.Options().apply {
                            inSampleSize = sampleSize
                            inPreferredConfig = Bitmap.Config.RGB_565 // oszczędność pamięci na Snapdragonie
                        }
                        BitmapFactory.decodeStream(decodeStream, null, finalOptions)
                    }
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun downsampleBitmap(data: ByteArray, reqW: Int, reqH: Int): Bitmap {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, options)
        options.inSampleSize = calculateInSampleSize(options, reqW, reqH)
        options.inJustDecodeBounds = false
        options.inPreferredConfig = Bitmap.Config.RGB_565
        return BitmapFactory.decodeByteArray(data, 0, data.size, options)
    }

    private fun calculateInSampleSize(opt: BitmapFactory.Options, reqW: Int, reqH: Int): Int {
        val (h, w) = opt.outHeight to opt.outWidth
        var inSampleSize = 1
        if (h > reqH || w > reqW) {
            val halfH = h / 2
            val halfW = w / 2
            while (halfH / inSampleSize >= reqH && halfW / inSampleSize >= reqW) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }
}