package com.photogallery.rawlens.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.photogallery.rawlens.ai.EmbeddingEngine
import com.photogallery.rawlens.data.AppDatabase
import com.photogallery.rawlens.data.Converters
import com.photogallery.rawlens.data.PhotoEntity
import com.photogallery.rawlens.utils.ExifHelper
import com.photogallery.rawlens.utils.PhotographerExif
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class GalleryViewModel(app: Application) : AndroidViewModel(app) {
    private val db = AppDatabase.getInstance(app)
    private val engine = EmbeddingEngine(app)

    private val _photos = MutableStateFlow<List<PhotoEntity>>(emptyList())
    val photos: StateFlow<List<PhotoEntity>> = _photos

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    private val _selectedPhoto = MutableStateFlow<PhotoEntity?>(null)
    val selectedPhoto: StateFlow<PhotoEntity?> = _selectedPhoto

    private val _currentExif = MutableStateFlow(PhotographerExif())
    val currentExif: StateFlow<PhotographerExif> = _currentExif

    init {
        loadPhotos()
    }

    fun loadPhotos() {
        viewModelScope.launch(Dispatchers.IO) {
            val list = db.photoDao().getAllPhotos()
            _photos.value = list
        }
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
        if (query.isBlank()) {
            loadPhotos()
            return
        }

        viewModelScope.launch(Dispatchers.Default) {
            val queryEmbedding = engine.embedText(query)
            val embeddedPhotos = db.photoDao().getAllEmbeddedPhotos()

            val ranked = embeddedPhotos.mapNotNull { photo ->
                val rawBytes = photo.embedding ?: return@mapNotNull null
                val vec = Converters.toFloatArray(rawBytes)
                val similarity = EmbeddingEngine.cosineSimilarity(queryEmbedding, vec)
                Pair(photo, similarity)
            }
            .filter { it.second > 0.18f } // Próg tolerancji wektorowej
            .sortedByDescending { it.second }
            .map { it.first }

            _photos.value = ranked
        }
    }

    fun selectPhoto(photo: PhotoEntity?) {
        _selectedPhoto.value = photo
        if (photo != null) {
            viewModelScope.launch(Dispatchers.IO) {
                val exif = ExifHelper.parseExif(getApplication(), Uri.parse(photo.uriString))
                _currentExif.value = exif
            }
        }
    }
}