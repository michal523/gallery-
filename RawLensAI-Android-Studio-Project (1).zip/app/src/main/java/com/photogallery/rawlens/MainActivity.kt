package com.photogallery.rawlens

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.photogallery.rawlens.ui.GalleryViewModel
import com.photogallery.rawlens.ui.MainGalleryScreen

class MainActivity : ComponentActivity() {
    private val viewModel: GalleryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MainGalleryScreen(viewModel = viewModel)
        }
    }
}