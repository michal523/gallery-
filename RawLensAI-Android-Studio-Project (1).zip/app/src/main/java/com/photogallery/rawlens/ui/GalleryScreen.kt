package com.photogallery.rawlens.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Camera
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.photogallery.rawlens.data.PhotoEntity
import com.photogallery.rawlens.utils.PhotographerExif

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainGalleryScreen(viewModel: GalleryViewModel) {
    val photos by viewModel.photos.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedPhoto by viewModel.selectedPhoto.collectAsState()
    val exifData by viewModel.currentExif.collectAsState()

    var showBottomSheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false)

    Scaffold(
        topBar = {
            SearchBar(
                query = searchQuery,
                onQueryChange = { viewModel.onSearchQueryChanged(it) },
                onSearch = {},
                active = false,
                onActiveChange = {},
                placeholder = { Text("Szukaj (np. 'zachód słońca', 'portret')...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {}
        }
    ) { innerPadding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(2.dp)
        ) {
            items(photos, key = { it.uriString }) { photo ->
                Box(
                    modifier = Modifier
                        .aspectRatio(1f)
                        .padding(2.dp)
                        .clickable { viewModel.selectPhoto(photo) }
                ) {
                    AsyncImage(
                        model = photo.uriString,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    // Plakietka informacyjna dla plików RAW
                    val ext = photo.filePath.substringAfterLast(".").uppercase()
                    if (ext in listOf("RW2", "CR3", "NEF", "DNG")) {
                        Text(
                            text = ext,
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(topStart = 4.dp))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }

        // Ekran pełnoekranowy wybranego zdjęcia z gestem przeciągnięcia w górę
        selectedPhoto?.let { photo ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
                    .pointerInput(Unit) {
                        detectVerticalDragGestures { _, dragAmount ->
                            if (dragAmount < -30) { // Przeciągnięcie w górę (Swipe UP)
                                showBottomSheet = true
                            }
                        }
                    }
            ) {
                AsyncImage(
                    model = photo.uriString,
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )

                IconButton(
                    onClick = { viewModel.selectPhoto(null) },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(16.dp)
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Zamknij", tint = Color.White)
                }

                // Wskaźnik przeciągnięcia na dole
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 16.dp)
                        .clickable { showBottomSheet = true },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.Camera, contentDescription = null, tint = Color.White.copy(alpha = 0.7f))
                    Text("Pociągnij w górę, aby zobaczyć EXIF", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                }
            }
        }

        // Moduł EXIF: Estetyczny panel fotografa (Bottom Sheet)
        if (showBottomSheet) {
            ModalBottomSheet(
                onDismissRequest = { showBottomSheet = false },
                sheetState = sheetState,
                containerColor = Color(0xFF1E1E1E)
            ) {
                PhotographerHudPanel(exif = exifData)
            }
        }
    }
}

@Composable
fun PhotographerHudPanel(exif: PhotographerExif) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp)
    ) {
        Text(
            text = "PARAMETRY EKSPOZYCJI & HISTOGRAM",
            color = Color(0xFFFFB300),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp
        )
        Spacer(modifier = Modifier.height(12.dp))

        // Histogram ekspozycji na Canvasie Jetpack Compose
        ExposureHistogramView()

        Spacer(modifier = Modifier.height(16.dp))

        // Główny pasek HUD: Ogniskowa, Przesłona, Czas, ISO
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF2C2C2C), RoundedCornerShape(8.dp))
                .padding(vertical = 12.dp, horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            HudParamItem("OGNISKOWA", exif.focalLength)
            HudParamItem("PRZYSŁONA", exif.aperture)
            HudParamItem("CZAS", exif.shutterSpeed)
            HudParamItem("CZUŁOŚĆ", exif.iso)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Metadane autora i prawa autorskie
        ExifDetailRow("Autor / Fotograf", exif.author)
        ExifDetailRow("Prawa autorskie", exif.copyright)
        if (exif.title.isNotBlank()) {
            ExifDetailRow("Tytuł zdjęcia", exif.title)
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Sprzęt i szczegóły techniczne
        ExifDetailRow("Aparat", exif.camera)
        ExifDetailRow("Obiektyw", exif.lens)
        ExifDetailRow("Rozdzielczość", exif.resolution)
        ExifDetailRow("Waga pliku", exif.fileSize)

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
fun ExposureHistogramView() {
    androidx.compose.foundation.Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(60.dp)
            .background(Color(0xFF141414), RoundedCornerShape(6.dp))
    ) {
        // Rysowanie wykresu fali luminancji ekspozycji
        val width = size.width
        val height = size.height
        val path = androidx.compose.ui.graphics.Path()
        path.moveTo(0f, height)
        for (i in 0..255) {
            val x = i * (width / 255f)
            val normalizedY = Math.sin(i / 30.0).toFloat().coerceIn(0f, 1f) * 0.7f + 0.1f
            val y = height - (normalizedY * height)
            path.lineTo(x, y)
        }
        path.lineTo(width, height)
        path.close()
        drawPath(path, color = Color(0xFFFFB300).copy(alpha = 0.5f))
    }
}

@Composable
fun HudParamItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun ExifDetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = Color.Gray, fontSize = 13.sp)
        Text(text = value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}