package com.photogallery.rawlens.data

import android.content.Context
import androidx.room.*
import java.nio.ByteBuffer
import java.nio.ByteOrder

@Entity(tableName = "photos")
data class PhotoEntity(
    @PrimaryKey val uriString: String,
    val filePath: String,
    val mimeType: String,
    val dateModified: Long,
    val embedding: ByteArray? // 768-dim FloatArray spakowany do ByteArray dla oszczędności RAM
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is PhotoEntity) return false
        return uriString == other.uriString
    }
    override fun hashCode(): Int = uriString.hashCode()
}

class Converters {
    companion object {
        fun toByteArray(floatArray: FloatArray): ByteArray {
            val byteBuffer = ByteBuffer.allocate(floatArray.size * 4).order(ByteOrder.LITTLE_ENDIAN)
            floatArray.forEach { byteBuffer.putFloat(it) }
            return byteBuffer.array()
        }

        fun toFloatArray(byteArray: ByteArray): FloatArray {
            val byteBuffer = ByteBuffer.wrap(byteArray).order(ByteOrder.LITTLE_ENDIAN)
            val floatArray = FloatArray(byteArray.size / 4)
            byteBuffer.asFloatBuffer().get(floatArray)
            return floatArray
        }
    }
}

@Dao
interface PhotoDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(photo: PhotoEntity)

    @Query("SELECT * FROM photos WHERE embedding IS NOT NULL")
    suspend fun getAllEmbeddedPhotos(): List<PhotoEntity>

    @Query("SELECT * FROM photos WHERE embedding IS NULL")
    suspend fun getUnprocessedPhotos(): List<PhotoEntity>

    @Query("SELECT * FROM photos ORDER BY dateModified DESC")
    suspend fun getAllPhotos(): List<PhotoEntity>
}

@Database(entities = [PhotoEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun photoDao(): PhotoDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "gallery.db")
                    .fallbackToDestructiveMigration()
                    .build().also { INSTANCE = it }
            }
    }
}