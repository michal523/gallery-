package com.photogallery.rawlens.worker

import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.work.*
import com.photogallery.rawlens.ai.EmbeddingEngine
import com.photogallery.rawlens.data.AppDatabase
import com.photogallery.rawlens.data.Converters
import com.photogallery.rawlens.data.PhotoEntity
import com.photogallery.rawlens.utils.ExifHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.TimeUnit

class PhotoIndexingWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val db = AppDatabase.getInstance(applicationContext)
        val engine = EmbeddingEngine(applicationContext)
        
        // 1. Zindeksuj nowe zdjęcia RAW/JPG ze schowka
        scanDevicePhotos(db)

        // 2. Generuj wektory partiami
        val unprocessed = db.photoDao().getUnprocessedPhotos()
        for (item in unprocessed) {
            val uri = Uri.parse(item.uriString)
            val thumb = ExifHelper.extractEmbeddedThumbnail(applicationContext, uri)
            if (thumb != null) {
                val embedding = engine.embedImage(thumb)
                thumb.recycle() // Natychmiastowe zwalnianie RAM
                db.photoDao().insertOrUpdate(
                    item.copy(embedding = Converters.toByteArray(embedding))
                )
            }
        }
        Result.success()
    }

    private suspend fun scanDevicePhotos(db: AppDatabase) {
        val extensions = arrayOf("jpg", "jpeg", "cr3", "nef", "rw2", "dng")
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DATA,
            MediaStore.Images.Media.MIME_TYPE,
            MediaStore.Images.Media.DATE_MODIFIED
        )
        
        applicationContext.contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            projection,
            null,
            null,
            "${MediaStore.Images.Media.DATE_MODIFIED} DESC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED)

            while (cursor.moveToNext()) {
                val path = cursor.getString(dataCol) ?: continue
                val ext = File(path).extension.lowercase()
                if (ext in extensions) {
                    val id = cursor.getLong(idCol)
                    val uri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())
                    val mime = cursor.getString(mimeCol) ?: "image/x-raw"
                    val date = cursor.getLong(dateCol)
                    
                    db.photoDao().insertOrUpdate(
                        PhotoEntity(uri.toString(), path, mime, date, null)
                    )
                }
            }
        }
    }
}

object WorkScheduler {
    fun scheduleBackgroundIndexing(context: Context) {
        val constraints = Constraints.Builder()
            .setRequiresCharging(true)       // Wyłącznie podczas ładowania
            .setRequiresDeviceIdle(true)     // Tylko w stanie bezczynności
            .build()

        val indexingRequest = PeriodicWorkRequestBuilder<PhotoIndexingWorker>(1, TimeUnit.HOURS)
            .setConstraints(constraints)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.MINUTES)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "RawLensAiIndexer",
            ExistingPeriodicWorkPolicy.KEEP,
            indexingRequest
        )
    }
}