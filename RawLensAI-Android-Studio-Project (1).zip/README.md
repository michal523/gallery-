# RAW Lens AI - Motorola Edge 50 Pro & Android

Aplikacja galerii zdjęć dedykowana fotografom, obsługująca pliki RAW (.RW2, .CR3, .NEF, .DNG) oraz .JPG z:
- **Wektorowym wyszukiwaniem semantycznym na urządzeniu (On-Device LiteRT / MediaPipe Tasks)**
- **Wydajnym przetwarzaniem w tle (WorkManager - wyłącznie podczas ładowania i bezczynności)**
- **Optymalizacją pamięci RAM (RGB_565, FloatArray -> ByteArray w bazie Room)**
- **HUD-em parametrów ekspozycji EXIF (Ogniskowa, Przesłona, Czas, Czułość ISO)**

## Szybka instalacja na telefonie:
1. Rozpakuj projekt lub pobierz plik `RawLensAI-v1.0-debug.apk`.
2. Prześlij na telefon Motorola Edge 50 Pro (lub dowolny telefon z Androidem 8.0 - 15).
3. Włącz w ustawieniach "Instalowanie aplikacji z nieznanych źródeł" i kliknij plik APK.

## Budowanie w Android Studio:
1. Otwórz pobrany katalog w Android Studio (Ladybug / Koala).
2. Poczekaj na automatyczną synchronizację Gradle.
3. Podłącz telefon z włączonym Debugowaniem USB (lub wybierz Emulator).
4. Kliknij **Run** (zielony trójkąt) lub w terminalu wpisz:
   ```bash
   ./gradlew assembleDebug
   ```
   Plik APK znajdziesz w: `app/build/outputs/apk/debug/app-debug.apk`
